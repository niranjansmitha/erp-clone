package com.peopleone.communication.dto;

import com.peopleone.communication.model.Announcement.Category;
import com.peopleone.communication.model.Announcement.Priority;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnnouncementResponse {
    private String id;
    private String title;
    private String content;
    private String authorId;
    private String targetDepartmentId;
    private String targetEmployeeId;
    private Category category;
    private Priority priority;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
