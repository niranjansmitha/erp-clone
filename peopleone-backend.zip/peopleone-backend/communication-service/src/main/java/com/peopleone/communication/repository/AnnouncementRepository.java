package com.peopleone.communication.repository;

import com.peopleone.communication.model.Announcement;
import com.peopleone.communication.model.Announcement.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AnnouncementRepository extends JpaRepository<Announcement, String> {

    @Query("SELECT a FROM Announcement a WHERE a.targetEmployeeId = :employeeId OR a.targetDepartmentId = :departmentId OR (a.targetEmployeeId IS NULL AND a.targetDepartmentId IS NULL) ORDER BY a.createdAt DESC")
    Page<Announcement> findPersonalizedFeed(@Param("employeeId") String employeeId, @Param("departmentId") String departmentId, Pageable pageable);

    Page<Announcement> findByCategoryOrderByCreatedAtDesc(Category category, Pageable pageable);
}
