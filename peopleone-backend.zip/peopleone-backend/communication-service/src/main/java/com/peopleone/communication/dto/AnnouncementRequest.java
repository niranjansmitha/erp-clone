package com.peopleone.communication.dto;

import com.peopleone.communication.model.Announcement.Category;
import com.peopleone.communication.model.Announcement.Priority;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnnouncementRequest {

    @NotBlank(message = "Title is required")
    private String title;

    @NotBlank(message = "Content is required")
    private String content;

    private String targetDepartmentId;
    
    private String targetEmployeeId;

    @NotNull(message = "Category is required")
    private Category category;

    @NotNull(message = "Priority is required")
    private Priority priority;

    @AssertTrue(message = "An announcement cannot target both a department and an employee simultaneously.")
    public boolean isValidTarget() {
        return !(targetDepartmentId != null && targetEmployeeId != null);
    }
}
