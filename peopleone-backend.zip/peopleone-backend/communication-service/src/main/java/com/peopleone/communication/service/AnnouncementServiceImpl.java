package com.peopleone.communication.service;

import com.peopleone.communication.dto.AnnouncementRequest;
import com.peopleone.communication.dto.AnnouncementResponse;
import com.peopleone.communication.exception.ResourceNotFoundException;
import com.peopleone.communication.model.Announcement;
import com.peopleone.communication.model.Announcement.Category;
import com.peopleone.communication.repository.AnnouncementRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AnnouncementServiceImpl implements AnnouncementService {

    private final AnnouncementRepository announcementRepository;

    @Override
    public AnnouncementResponse createAnnouncement(AnnouncementRequest request, String authorId) {
        Announcement announcement = new Announcement();
        mapRequestToEntity(request, announcement);
        announcement.setAuthorId(authorId);
        Announcement saved = announcementRepository.save(announcement);
        return mapEntityToResponse(saved);
    }

    @Override
    public AnnouncementResponse getAnnouncementById(String id) {
        Announcement announcement = announcementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Announcement not found with id: " + id));
        return mapEntityToResponse(announcement);
    }

    @Override
    public Page<AnnouncementResponse> getPersonalizedFeed(String employeeId, String departmentId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Announcement> announcements = announcementRepository.findPersonalizedFeed(employeeId, departmentId, pageable);
        return announcements.map(this::mapEntityToResponse);
    }

    @Override
    public Page<AnnouncementResponse> getAnnouncementsByCategory(String category, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Category enumCategory = Category.valueOf(category.toUpperCase());
        Page<Announcement> announcements = announcementRepository.findByCategoryOrderByCreatedAtDesc(enumCategory, pageable);
        return announcements.map(this::mapEntityToResponse);
    }

    @Override
    public AnnouncementResponse updateAnnouncement(String id, AnnouncementRequest request) {
        Announcement announcement = announcementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Announcement not found with id: " + id));
        
        mapRequestToEntity(request, announcement);
        Announcement updated = announcementRepository.save(announcement);
        return mapEntityToResponse(updated);
    }

    @Override
    public void deleteAnnouncement(String id) {
        Announcement announcement = announcementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Announcement not found with id: " + id));
        announcementRepository.delete(announcement);
    }

    private void mapRequestToEntity(AnnouncementRequest request, Announcement entity) {
        entity.setTitle(request.getTitle());
        entity.setContent(request.getContent());
        entity.setTargetDepartmentId(request.getTargetDepartmentId());
        entity.setTargetEmployeeId(request.getTargetEmployeeId());
        entity.setCategory(request.getCategory());
        entity.setPriority(request.getPriority());
    }

    private AnnouncementResponse mapEntityToResponse(Announcement entity) {
        return new AnnouncementResponse(
                entity.getId(),
                entity.getTitle(),
                entity.getContent(),
                entity.getAuthorId(),
                entity.getTargetDepartmentId(),
                entity.getTargetEmployeeId(),
                entity.getCategory(),
                entity.getPriority(),
                entity.getCreatedAt(),
                entity.getUpdatedAt()
        );
    }
}
