package com.peopleone.communication.service;

import com.peopleone.communication.dto.AnnouncementRequest;
import com.peopleone.communication.dto.AnnouncementResponse;
import org.springframework.data.domain.Page;

public interface AnnouncementService {
    AnnouncementResponse createAnnouncement(AnnouncementRequest request, String authorId);
    AnnouncementResponse getAnnouncementById(String id);
    Page<AnnouncementResponse> getPersonalizedFeed(String employeeId, String departmentId, int page, int size);
    Page<AnnouncementResponse> getAnnouncementsByCategory(String category, int page, int size);
    AnnouncementResponse updateAnnouncement(String id, AnnouncementRequest request);
    void deleteAnnouncement(String id);
}
