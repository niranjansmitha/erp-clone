package com.peopleone.user.model;

public enum Role {
    USER,
    ADMIN
}
