package com.peopleone.user.service;

import com.peopleone.user.dto.AuthRequest;
import com.peopleone.user.dto.AuthResponse;
import com.peopleone.user.dto.RegisterRequest;
import com.peopleone.user.model.Employee;
import com.peopleone.user.model.Role;
import com.peopleone.user.model.UserAuth;
import com.peopleone.user.repository.EmployeeRepository;
import com.peopleone.user.repository.UserAuthRepository;
import com.peopleone.user.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserAuthRepository userAuthRepository;
    private final EmployeeRepository employeeRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public void register(RegisterRequest request) {
        if (userAuthRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("User already exists with this email");
        }

        // Auto-create Employee if they don't exist
        String employeeId = request.getEmployeeId();
        if (employeeId == null || employeeId.isEmpty() || !employeeRepository.existsById(employeeId)) {
            Employee employee = new Employee();
            if (employeeId != null && !employeeId.isEmpty()) {
                employee.setId(employeeId); // If they provided an ID but it doesn't exist, try to use it
            }
            employee.setSystemEmailId(request.getEmail());
            employee.setFirstName(request.getFirstName() != null ? request.getFirstName() : "New");
            employee.setLastName(request.getLastName() != null ? request.getLastName() : "User");
            employee.setRole(request.getRole());
            employee.setCreatedAt(LocalDateTime.now());
            employee.setUpdatedAt(LocalDateTime.now());

            // Save employee to generate ID if null, or persist the provided ID
            employee = employeeRepository.save(employee);
            employeeId = employee.getId();
        }

        UserAuth user = new UserAuth();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(Role.valueOf(request.getRole()));
        user.setEmployeeId(employeeId); // Use the generated or existing employee ID

        userAuthRepository.save(user);
    }

    public AuthResponse login(AuthRequest request) {
        UserAuth user = userAuthRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtUtil.generateToken(user.getEmployeeId(), user.getRole().name());
        return new AuthResponse(token);
    }
}
