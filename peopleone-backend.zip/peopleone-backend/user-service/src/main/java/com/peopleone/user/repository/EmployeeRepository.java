package com.peopleone.user.repository;

import com.peopleone.user.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {

    @Query(value = "SELECT manager_id FROM employee_job_details WHERE employee_id = :employeeId", nativeQuery = true)
    String findManagerIdByEmployeeId(@Param("employeeId") String employeeId);
}