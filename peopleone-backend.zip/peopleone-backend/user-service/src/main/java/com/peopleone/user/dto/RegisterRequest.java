package com.peopleone.user.dto;

import lombok.Data;

@Data
public class RegisterRequest {
    private String email;
    private String password;
    private String role; // e.g., "ROLE_ADMIN" or "ROLE_USER"
    private String employeeId;
    private String firstName;
    private String lastName;
}
