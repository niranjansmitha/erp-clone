package com.peopleone.engagement.engagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EngagementMsApplicationTests {

    @Test
    void contextLoads() {
    }

}
