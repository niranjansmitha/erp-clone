package com.peopleone.engagement.service;
import com.peopleone.engagement.model.Kudos;
import com.peopleone.engagement.repository.KudosRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KudosService {

    private final KudosRepository repository;

    public KudosService(KudosRepository repository) {
        this.repository = repository;
    }



    public Kudos send(Kudos kudos) {
        return repository.save(kudos);
    }

    public List<Kudos> getAll() {
        return repository.findAll();
    }

    public List<Kudos> getByEmployee(String id) {
        return repository.findByReceiverId(id);
    }

    public Kudos update(Long id, Kudos updated) {

        Kudos existing = repository.findById(id).orElseThrow();

        existing.setTitle(updated.getTitle());
        existing.setMessage(updated.getMessage());

        return repository.save(existing);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

}