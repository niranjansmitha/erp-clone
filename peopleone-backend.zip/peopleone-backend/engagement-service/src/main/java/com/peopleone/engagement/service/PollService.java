package com.peopleone.engagement.service;

import com.peopleone.engagement.model.Poll;
import com.peopleone.engagement.model.PollVote;
import com.peopleone.engagement.repository.PollRepository;
import com.peopleone.engagement.repository.PollVoteRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PollService {

    private final PollRepository pollRepository;
    private final PollVoteRepository voteRepository;

    public PollService(PollRepository pollRepository,
                       PollVoteRepository voteRepository) {

        this.pollRepository = pollRepository;
        this.voteRepository = voteRepository;
    }

    public Poll createPoll(Poll poll) {
        return pollRepository.save(poll);
    }

    public List<Poll> getAllPolls() {
        return pollRepository.findAll();
    }

    public Poll getPoll(Long id) {
        return pollRepository.findById(id).orElseThrow();
    }

    public Poll updatePoll(Long id, Poll updated) {

        Poll existing = pollRepository.findById(id).orElseThrow();

        existing.setQuestion(updated.getQuestion());
        existing.setOption1(updated.getOption1());
        existing.setOption2(updated.getOption2());
        existing.setOption3(updated.getOption3());
        existing.setOption4(updated.getOption4());
        existing.setActive(updated.isActive());

        return pollRepository.save(existing);
    }

    public void deletePoll(Long id) {
        pollRepository.deleteById(id);
    }

    public PollVote vote(Long pollId, PollVote vote) {

        Poll poll = pollRepository.findById(pollId).orElseThrow();

        if (!poll.isActive()) {
            throw new RuntimeException("Poll is closed");
        }

        if (voteRepository.findByPollIdAndEmployeeId(
                pollId,
                vote.getEmployeeId()).isPresent()) {

            throw new RuntimeException("Employee has already voted");
        }

        vote.setPollId(pollId);

        return voteRepository.save(vote);
    }

    public Map<String, Integer> getResults(Long pollId) {

        List<PollVote> votes = voteRepository.findByPollId(pollId);

        Map<String, Integer> results = new HashMap<>();

        for (PollVote vote : votes) {

            results.put(
                    vote.getSelectedOption(),
                    results.getOrDefault(
                            vote.getSelectedOption(),
                            0) + 1);
        }

        return results;
    }

}