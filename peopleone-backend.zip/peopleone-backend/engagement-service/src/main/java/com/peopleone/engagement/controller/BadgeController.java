package com.peopleone.engagement.controller;

import com.peopleone.engagement.model.Badge;
import com.peopleone.engagement.service.BadgeService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/badges")
public class BadgeController {

    private final BadgeService service;

    public BadgeController(BadgeService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Badge awardBadge(@RequestBody Badge badge) {
        return service.awardBadge(badge);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<Badge> getAllBadges() {
        return service.getAllBadges();
    }

    @GetMapping("/employee/{employeeId}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<Badge> getEmployeeBadges(
            @PathVariable String employeeId) {
        return service.getEmployeeBadges(employeeId);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Badge updateBadge(@PathVariable  Long id,
                             @RequestBody Badge badge) {
        return service.updateBadge(id, badge);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public void deleteBadge(@PathVariable Long id) {
        service.deleteBadge(id);
    }

}