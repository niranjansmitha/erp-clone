package com.peopleone.engagement.repository;

import com.peopleone.engagement.model.Kudos;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface KudosRepository extends JpaRepository<Kudos, Long> {

    List<Kudos> findByReceiverId(String receiverId);

}