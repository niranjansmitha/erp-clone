package com.peopleone.engagement.repository;

import com.peopleone.engagement.model.Poll;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PollRepository extends JpaRepository<Poll, Long> {
}