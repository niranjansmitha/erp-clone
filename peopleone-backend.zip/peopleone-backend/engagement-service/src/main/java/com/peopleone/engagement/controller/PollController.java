package com.peopleone.engagement.controller;

import com.peopleone.engagement.model.Poll;
import com.peopleone.engagement.model.PollVote;
import com.peopleone.engagement.service.PollService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/polls")
public class PollController {

    private final PollService service;

    public PollController(PollService service) {
        this.service = service;
    }

    // Create Poll
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Poll createPoll(@RequestBody Poll poll) {
        return service.createPoll(poll);
    }

    // Get All Polls
    @GetMapping
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<Poll> getAllPolls() {
        return service.getAllPolls();
    }

    // Get Poll By ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public Poll getPoll(@PathVariable Long id) {
        return service.getPoll(id);
    }

    // Update Poll
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Poll updatePoll(@PathVariable Long id,
                           @RequestBody Poll poll) {
        return service.updatePoll(id, poll);
    }

    // Delete Poll
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deletePoll(@PathVariable Long id) {
        service.deletePoll(id);
        return "Poll deleted successfully.";
    }

    // Vote in Poll
    @PostMapping("/{pollId}/vote")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public PollVote vote(@PathVariable Long pollId,
                         @RequestBody PollVote vote) {
        return service.vote(pollId, vote);
    }

    // View Poll Results
    @GetMapping("/{pollId}/results")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public Map<String, Integer> getResults(
            @PathVariable Long pollId) {
        return service.getResults(pollId);
    }
}