package com.peopleone.engagement.repository;

import com.peopleone.engagement.model.Badge;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BadgeRepository extends JpaRepository<Badge, Long> {

    List<Badge> findByEmployeeId(String employeeId);

}