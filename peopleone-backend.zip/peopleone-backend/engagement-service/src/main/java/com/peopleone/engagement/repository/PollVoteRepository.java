package com.peopleone.engagement.repository;

import com.peopleone.engagement.model.PollVote;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PollVoteRepository extends JpaRepository<PollVote, Long> {

    Optional<PollVote> findByPollIdAndEmployeeId(Long pollId,
                                                 String employeeId);

    List<PollVote> findByPollId(Long pollId);

}