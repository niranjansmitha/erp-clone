package com.peopleone.knowledge.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.peopleone.knowledge.model.PolicyDocument;
import com.peopleone.knowledge.service.PolicyService;

@RestController
@RequestMapping("/api/v1/policies")
public class PolicyController {

    private final PolicyService service;

    public PolicyController(PolicyService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<PolicyDocument> getAllPolicies() {

        return service.getAllPolicies();
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public PolicyDocument getPolicy(@PathVariable String id) {

        return service.getPolicyById(id);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public PolicyDocument createPolicy(@RequestBody PolicyDocument policy) {

        return service.createPolicy(policy);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public PolicyDocument updatePolicy(
            @PathVariable String id,
            @RequestBody PolicyDocument policy) {

        return service.updatePolicy(id, policy);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public void deletePolicy(@PathVariable String id) {

        service.deletePolicy(id);
    }

    @GetMapping("/category/{category}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<PolicyDocument> getByCategory(
            @PathVariable String category) {

        return service.getByCategory(category);
    }

    @GetMapping("/search")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<PolicyDocument> search(
            @RequestParam String title) {

        return service.searchByTitle(title);
    }

}