package com.peopleone.attendance.repository;

import com.peopleone.attendance.model.EmployeeLeaveBalance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface LeaveBalanceRepository extends JpaRepository<EmployeeLeaveBalance, UUID> {

    List<EmployeeLeaveBalance> findByEmployeeIdAndYear(UUID employeeId, int year);

    EmployeeLeaveBalance findByEmployeeIdAndLeaveTypeAndYear(UUID employeeId, String leaveType, int year);
}
