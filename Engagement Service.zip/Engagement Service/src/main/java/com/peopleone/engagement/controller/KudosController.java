package com.peopleone.engagement.controller;

import com.peopleone.engagement.model.Kudos;
import com.peopleone.engagement.service.KudosService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/kudos")
public class KudosController {

    private final KudosService service;

    public KudosController(KudosService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public Kudos send(@RequestBody Kudos kudos) {
        return service.send(kudos);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<Kudos> getAll() {
        return service.getAll();
    }

    @GetMapping("/employee/{id}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public List<Kudos> getByEmployee(@PathVariable String id) {
        return service.getByEmployee(id);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public Kudos update(@PathVariable Long id,
                        @RequestBody Kudos kudos) {
        return service.update(id, kudos);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

}