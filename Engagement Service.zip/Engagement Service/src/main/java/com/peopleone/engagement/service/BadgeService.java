package com.peopleone.engagement.service;

import com.peopleone.engagement.client.UserClient;
import com.peopleone.engagement.model.Badge;
import com.peopleone.engagement.repository.BadgeRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BadgeService {

    private final BadgeRepository repository;
    private final UserClient userClient;

    public BadgeService(BadgeRepository repository,
                        UserClient userClient) {
        this.repository = repository;
        this.userClient = userClient;
    }

    public Badge awardBadge(Badge badge) {

        // Verify employee exists
        userClient.getUser(badge.getEmployeeId());

        badge.setAwardedOn(LocalDate.now());

        return repository.save(badge);
    }

    public List<Badge> getAllBadges() {
        return repository.findAll();
    }

    public List<Badge> getEmployeeBadges(String employeeId) {
        return repository.findByEmployeeId(employeeId);
    }

    public Badge updateBadge(Long id, Badge updatedBadge) {

        Badge existing = repository.findById(id).orElseThrow();

        existing.setBadgeName(updatedBadge.getBadgeName());
        existing.setDescription(updatedBadge.getDescription());

        return repository.save(existing);
    }

    public void deleteBadge(Long id) {
        repository.deleteById(id);
    }

}