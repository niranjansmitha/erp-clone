package com.peopleone.engagement.config;

import feign.RequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Configuration
public class FeignConfig {

    @Bean
    public RequestInterceptor basicAuthRequestInterceptor() {

        return requestTemplate -> {

            String username = "admin";
            String password = "admin@123";

            String credentials = username + ":" + password;

            String encodedCredentials = Base64.getEncoder()
                    .encodeToString(credentials.getBytes(StandardCharsets.UTF_8));

            requestTemplate.header(
                    "Authorization",
                    "Basic " + encodedCredentials
            );
        };
    }
}