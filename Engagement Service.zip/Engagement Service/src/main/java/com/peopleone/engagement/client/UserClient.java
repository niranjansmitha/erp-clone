package com.peopleone.engagement.client;

import com.peopleone.engagement.config.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
        name = "user-service",
        configuration = FeignConfig.class
)
public interface UserClient {

    @GetMapping("/api/users/{id}")
    Object getUser(@PathVariable String id);

}