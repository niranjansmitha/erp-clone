package com.peopleone.attendance.service;

import com.peopleone.attendance.client.UserClient;
import com.peopleone.attendance.model.LeaveRequest;
import com.peopleone.attendance.model.LeaveStatus; // Import added here
import com.peopleone.attendance.repository.LeaveRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class LeaveService {

    private final LeaveRepository leaveRepository;
    private final UserClient userClient;
    
    public LeaveService(LeaveRepository leaveRepository, UserClient userClient) {
        this.leaveRepository = leaveRepository;
        this.userClient = userClient;
    }

    @Transactional
    public LeaveRequest applyForLeave(LeaveRequest leaveRequest) {
        UUID managerId = userClient.getManagerIdForEmployee(leaveRequest.getEmployeeId());
        
        if (managerId == null) {
            throw new RuntimeException("Reporting manager not found for employee");
        }

        leaveRequest.setManagerId(managerId);
        return leaveRepository.save(leaveRequest);
    }

    public List<LeaveRequest> getLeavesByEmployee(UUID employeeId) {
        return leaveRepository.findByEmployeeId(employeeId);
    }
    
    @Transactional
    public LeaveRequest updateLeaveStatus(UUID leaveId, String status) {
        LeaveRequest request = leaveRepository.findById(leaveId)
                .orElseThrow(() -> new RuntimeException("Leave request not found"));
                
        // Much cleaner implementation now that LeaveStatus is public
        request.setStatus(LeaveStatus.valueOf(status.toUpperCase()));
        
        return leaveRepository.save(request);
    }
}