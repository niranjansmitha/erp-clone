package com.peopleone.attendance.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.UUID;

// 'user-service' must match the spring.application.name of the User microservice
//Add the configuration parameter here
@FeignClient(name = "user-service", configuration = FeignSecurityConfig.class)
public interface UserClient {

 @GetMapping("/api/users/{employeeId}/manager-id")
 UUID getManagerIdForEmployee(@PathVariable("employeeId") UUID employeeId);
}