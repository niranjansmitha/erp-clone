package com.peopleone.attendance.client;

import feign.auth.BasicAuthRequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignSecurityConfig {

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        // Send the admin credentials you configured in user-service
        return new BasicAuthRequestInterceptor("admin", "admin@123");
    }
}