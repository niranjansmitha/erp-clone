package com.peopleone.attendance.model;

public enum LeaveStatus {
    PENDING, APPROVED, REJECTED, CANCELLED
}