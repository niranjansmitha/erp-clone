package com.peopleone.attendance.model;

public enum LeaveType {
    SICK, CASUAL, EARNED, MATERNITY
}