package com.peopleone.knowledge.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.peopleone.knowledge.model.PolicyDocument;

@Repository
public interface PolicyRepository extends JpaRepository<PolicyDocument, String>{

    List<PolicyDocument> findByCategory(String category);

    List<PolicyDocument> findByStatus(String status);

    List<PolicyDocument> findByTitleContainingIgnoreCase(String title);

}