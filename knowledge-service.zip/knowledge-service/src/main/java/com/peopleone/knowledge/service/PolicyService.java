package com.peopleone.knowledge.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.peopleone.knowledge.model.PolicyDocument;
import com.peopleone.knowledge.repository.PolicyRepository;

@Service
public class PolicyService {

    private final PolicyRepository repository;

    public PolicyService(PolicyRepository repository) {
        this.repository = repository;
    }

    public List<PolicyDocument> getAllPolicies() {
        return repository.findAll();
    }

    public PolicyDocument getPolicyById(String id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Policy not found"));
    }

    public PolicyDocument createPolicy(PolicyDocument policy) {

        policy.setId(UUID.randomUUID().toString());

        policy.setCreatedAt(LocalDateTime.now());

        policy.setUpdatedAt(LocalDateTime.now());

        return repository.save(policy);
    }

    public PolicyDocument updatePolicy(String id, PolicyDocument updated) {

        PolicyDocument policy = getPolicyById(id);

        policy.setTitle(updated.getTitle());
        policy.setDescription(updated.getDescription());
        policy.setCategory(updated.getCategory());
        policy.setVersion(updated.getVersion());
        policy.setFileUrl(updated.getFileUrl());
        policy.setUploadedBy(updated.getUploadedBy());
        policy.setEffectiveDate(updated.getEffectiveDate());
        policy.setExpiryDate(updated.getExpiryDate());
        policy.setStatus(updated.getStatus());

        policy.setUpdatedAt(LocalDateTime.now());

        return repository.save(policy);
    }

    public void deletePolicy(String id) {

        PolicyDocument policy = getPolicyById(id);

        repository.delete(policy);
    }

    public List<PolicyDocument> getByCategory(String category) {

        return repository.findByCategory(category);
    }

    public List<PolicyDocument> searchByTitle(String title) {

        return repository.findByTitleContainingIgnoreCase(title);
    }

}